package com.servicehub.exception;

/** Exceção para entidades não encontradas por id. */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
