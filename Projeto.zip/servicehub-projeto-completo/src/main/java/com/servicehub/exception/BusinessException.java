package com.servicehub.exception;

/** Exceção para violações de regra de negócio (ex.: estoque insuficiente). */
public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}
