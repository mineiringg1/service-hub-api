package com.servicehub.exception;

import java.time.LocalDateTime;
import java.util.List;

/** Formato padronizado de erro retornado pela API. */
public record ErrorResponse(
        LocalDateTime timestamp,
        int status,
        String error,
        String message,
        List<String> detalhes
) {
    public static ErrorResponse of(int status, String error, String message) {
        return new ErrorResponse(LocalDateTime.now(), status, error, message, List.of());
    }

    public static ErrorResponse of(int status, String error, String message, List<String> detalhes) {
        return new ErrorResponse(LocalDateTime.now(), status, error, message, detalhes);
    }
}
