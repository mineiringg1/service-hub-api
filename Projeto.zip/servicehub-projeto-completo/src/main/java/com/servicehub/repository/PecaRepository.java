package com.servicehub.repository;

import com.servicehub.model.Peca;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface PecaRepository extends JpaRepository<Peca, Long> {

    /*
     * PESSIMISTIC_WRITE: bloqueia a linha da peça durante a baixa de estoque
     * dentro da transação de CONCLUSAO da OS, evitando race condition entre
     * duas OS's concorrentes disputando a mesma peça.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Peca p WHERE p.id = :id")
    Optional<Peca> buscarComLockParaAtualizacao(Long id);
}
