package com.servicehub.repository;

import com.servicehub.model.Veiculo;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface VeiculoRepository extends JpaRepository<Veiculo, Long> {

    // Evita N+1 quando o Service acessa veiculo.getCliente() logo em seguida.
    @EntityGraph(attributePaths = "cliente")
    Optional<Veiculo> findWithClienteById(Long id);
}
