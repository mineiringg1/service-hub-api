package com.servicehub.repository;

import com.servicehub.model.OrdemServicoPeca;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdemServicoPecaRepository extends JpaRepository<OrdemServicoPeca, Long> {
}
