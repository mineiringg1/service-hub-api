package com.servicehub.repository;

import com.servicehub.model.OrdemServico;
import com.servicehub.model.StatusOS;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface OrdemServicoRepository extends JpaRepository<OrdemServico, Long> {

    /*
     * @EntityGraph carrega veiculo + cliente + itens + peca em uma única query,
     * evitando N+1 ao montar o DTO de resposta (que acessa esses campos).
     */
    @EntityGraph(attributePaths = {
            "veiculo",
            "veiculo.cliente",
            "itens",
            "itens.peca"
    })
    @Query("SELECT os FROM OrdemServico os WHERE os.id = :id")
    Optional<OrdemServico> buscarComItensPorId(@Param("id") Long id);

    @EntityGraph(attributePaths = {"veiculo", "veiculo.cliente"})
    @Query("SELECT os FROM OrdemServico os")
    List<OrdemServico> listarTodasComVeiculo();

    @EntityGraph(attributePaths = {"veiculo", "veiculo.cliente"})
    List<OrdemServico> findByStatus(StatusOS status);
}
