package com.servicehub.controller;

import com.servicehub.dto.request.AdicionarPecaRequest;
import com.servicehub.dto.request.CriarOrdemServicoRequest;
import com.servicehub.dto.response.OrdemServicoResponse;
import com.servicehub.service.OrdemServicoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

/**
 * Camada fina: nenhuma regra de negócio aqui, apenas mapeamento
 * HTTP <-> Service e construção de respostas.
 */
@RestController
@RequestMapping("/api/ordens-servico")
@RequiredArgsConstructor
public class OrdemServicoController {

    private final OrdemServicoService ordemServicoService;

    @PostMapping
    public ResponseEntity<OrdemServicoResponse> criar(@Valid @RequestBody CriarOrdemServicoRequest request) {
        OrdemServicoResponse response = ordemServicoService.criar(request);
        return ResponseEntity.created(URI.create("/api/ordens-servico/" + response.id())).body(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrdemServicoResponse> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(ordemServicoService.buscarPorId(id));
    }

    @GetMapping
    public ResponseEntity<List<OrdemServicoResponse>> listarTodas() {
        return ResponseEntity.ok(ordemServicoService.listarTodas());
    }

    @PostMapping("/{id}/pecas")
    public ResponseEntity<OrdemServicoResponse> adicionarPeca(
            @PathVariable Long id,
            @Valid @RequestBody AdicionarPecaRequest request) {
        return ResponseEntity.ok(ordemServicoService.adicionarPeca(id, request));
    }

    /*
     * PATCH em vez de PUT: é uma transição de estado pontual (ABERTA/EM_ANDAMENTO -> CONCLUIDA),
     * não uma substituição completa do recurso.
     */
    @PatchMapping("/{id}/concluir")
    public ResponseEntity<OrdemServicoResponse> concluir(@PathVariable Long id) {
        return ResponseEntity.ok(ordemServicoService.concluir(id));
    }
}
