package com.servicehub.dto.response;

import com.servicehub.model.StatusOS;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record OrdemServicoResponse(
        Long id,
        Long veiculoId,
        String placaVeiculo,
        String descricaoProblema,
        StatusOS status,
        BigDecimal maoDeObra,
        BigDecimal valorTotal,
        LocalDateTime criadoEm,
        List<ItemOSResponse> itens
) {}
