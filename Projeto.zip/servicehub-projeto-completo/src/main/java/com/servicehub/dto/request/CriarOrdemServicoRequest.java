package com.servicehub.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

public record CriarOrdemServicoRequest(
        @NotNull Long veiculoId,
        @NotBlank String descricaoProblema,
        @NotNull @PositiveOrZero BigDecimal maoDeObra
) {}
