package com.servicehub.dto.response;

import java.math.BigDecimal;

public record ItemOSResponse(
        Long pecaId,
        String nomePeca,
        Integer quantidade,
        BigDecimal precoPraticado
) {}
