package com.servicehub.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record AdicionarPecaRequest(
        @NotNull Long pecaId,
        @Min(1) Integer quantidade
) {}
