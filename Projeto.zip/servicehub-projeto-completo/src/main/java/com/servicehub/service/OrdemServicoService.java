package com.servicehub.service;

import com.servicehub.dto.request.AdicionarPecaRequest;
import com.servicehub.dto.request.CriarOrdemServicoRequest;
import com.servicehub.dto.response.ItemOSResponse;
import com.servicehub.dto.response.OrdemServicoResponse;
import com.servicehub.exception.BusinessException;
import com.servicehub.exception.ResourceNotFoundException;
import com.servicehub.model.*;
import com.servicehub.repository.OrdemServicoRepository;
import com.servicehub.repository.PecaRepository;
import com.servicehub.repository.VeiculoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrdemServicoService {

    private final OrdemServicoRepository ordemServicoRepository;
    private final VeiculoRepository veiculoRepository;
    private final PecaRepository pecaRepository;

    @Transactional
    public OrdemServicoResponse criar(CriarOrdemServicoRequest request) {
        Veiculo veiculo = veiculoRepository.findById(request.veiculoId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo não encontrado: " + request.veiculoId()));

        OrdemServico os = new OrdemServico();
        os.setVeiculo(veiculo);
        os.setDescricaoProblema(request.descricaoProblema());
        os.setMaoDeObra(request.maoDeObra());
        os.setStatus(StatusOS.ABERTA);
        os.setValorTotal(request.maoDeObra()); // ainda sem peças

        return toResponse(ordemServicoRepository.save(os));
    }

    @Transactional
    public OrdemServicoResponse adicionarPeca(Long ordemServicoId, AdicionarPecaRequest request) {
        OrdemServico os = buscarOSOuFalhar(ordemServicoId);

        if (os.getStatus() != StatusOS.ABERTA && os.getStatus() != StatusOS.EM_ANDAMENTO) {
            throw new BusinessException(
                    "Só é possível adicionar peças em OS ABERTA ou EM_ANDAMENTO.");
        }

        Peca peca = pecaRepository.findById(request.pecaId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Peça não encontrada: " + request.pecaId()));

        // Congela o preço atual da peça no item — histórico não é afetado
        // por reajustes futuros no cadastro da Peça.
        OrdemServicoPeca item = new OrdemServicoPeca();
        item.setOrdemServico(os);
        item.setPeca(peca);
        item.setQuantidade(request.quantidade());
        item.setPrecoPraticado(peca.getPrecoUnitario());

        os.getItens().add(item);
        recalcularValorTotal(os);

        return toResponse(ordemServicoRepository.save(os));
    }

    /**
     * Transição de status para CONCLUIDA: dá baixa no estoque de cada peça
     * associada. Toda a operação é atômica — se qualquer peça não tiver
     * estoque suficiente, a exceção de negócio reverte a transação inteira
     * (nenhuma peça é debitada parcialmente).
     */
    @Transactional
    public OrdemServicoResponse concluir(Long ordemServicoId) {
        OrdemServico os = buscarOSOuFalhar(ordemServicoId);

        if (os.getStatus() == StatusOS.CONCLUIDA) {
            throw new BusinessException("OS já está CONCLUIDA.");
        }
        if (os.getStatus() == StatusOS.CANCELADA) {
            throw new BusinessException("OS CANCELADA não pode ser concluída.");
        }
        if (os.getItens().isEmpty() && os.getMaoDeObra().compareTo(BigDecimal.ZERO) == 0) {
            throw new BusinessException("OS sem peças e sem mão de obra não pode ser concluída.");
        }

        for (OrdemServicoPeca item : os.getItens()) {
            baixarEstoque(item);
        }

        os.setStatus(StatusOS.CONCLUIDA);
        recalcularValorTotal(os);

        return toResponse(ordemServicoRepository.save(os));
    }

    private void baixarEstoque(OrdemServicoPeca item) {
        // Lock pessimista: garante leitura+escrita atômica da linha da peça,
        // essencial para não permitir overselling em concorrência.
        Peca peca = pecaRepository.buscarComLockParaAtualizacao(item.getPeca().getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Peça não encontrada: " + item.getPeca().getId()));

        if (peca.getQuantidadeEstoque() < item.getQuantidade()) {
            throw new BusinessException(
                    "Estoque insuficiente para a peça '%s'. Disponível: %d, solicitado: %d"
                            .formatted(peca.getNome(), peca.getQuantidadeEstoque(), item.getQuantidade()));
        }

        peca.setQuantidadeEstoque(peca.getQuantidadeEstoque() - item.getQuantidade());
        pecaRepository.save(peca);
    }

    private void recalcularValorTotal(OrdemServico os) {
        BigDecimal totalPecas = os.getItens().stream()
                .map(item -> item.getPrecoPraticado().multiply(BigDecimal.valueOf(item.getQuantidade())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        os.setValorTotal(os.getMaoDeObra().add(totalPecas));
    }

    @Transactional(readOnly = true)
    public OrdemServicoResponse buscarPorId(Long id) {
        return toResponse(buscarOSOuFalhar(id));
    }

    @Transactional(readOnly = true)
    public List<OrdemServicoResponse> listarTodas() {
        return ordemServicoRepository.listarTodasComVeiculo().stream()
                .map(this::toResponse)
                .toList();
    }

    private OrdemServico buscarOSOuFalhar(Long id) {
        return ordemServicoRepository.buscarComItensPorId(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ordem de Serviço não encontrada: " + id));
    }

    private OrdemServicoResponse toResponse(OrdemServico os) {
        List<ItemOSResponse> itens = os.getItens().stream()
                .map(i -> new ItemOSResponse(
                        i.getPeca().getId(),
                        i.getPeca().getNome(),
                        i.getQuantidade(),
                        i.getPrecoPraticado()))
                .toList();

        return new OrdemServicoResponse(
                os.getId(),
                os.getVeiculo().getId(),
                os.getVeiculo().getPlaca(),
                os.getDescricaoProblema(),
                os.getStatus(),
                os.getMaoDeObra(),
                os.getValorTotal(),
                os.getCriadoEm(),
                itens
        );
    }
}
