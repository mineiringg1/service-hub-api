package com.servicehub.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "peca")
@Getter
@Setter
@NoArgsConstructor
public class Peca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    // BigDecimal obrigatório para valores monetários — Double/Float
    // introduzem erro de arredondamento binário inaceitável em dinheiro.
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal precoUnitario;

    @Column(nullable = false)
    private Integer quantidadeEstoque;

    // Versão para lock otimista adicional na entidade (complementa o
    // PESSIMISTIC_WRITE usado explicitamente na baixa de estoque).
    @Version
    private Long version;
}
