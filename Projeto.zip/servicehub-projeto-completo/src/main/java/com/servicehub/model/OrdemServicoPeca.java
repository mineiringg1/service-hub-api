package com.servicehub.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "ordem_servico_peca")
@Getter
@Setter
@NoArgsConstructor
public class OrdemServicoPeca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ordem_servico_id", nullable = false)
    private OrdemServico ordemServico;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "peca_id", nullable = false)
    private Peca peca;

    @Column(nullable = false)
    private Integer quantidade;

    // Cópia histórica do preço da Peça no momento da associação — não
    // deve ser recalculado a partir de Peca.precoUnitario depois de gravado.
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal precoPraticado;
}
